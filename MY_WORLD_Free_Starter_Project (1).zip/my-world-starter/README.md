# MY WORLD – Free Starter App

A responsive starter PWA built with HTML, CSS and vanilla JavaScript. It can be hosted free on GitHub Pages.

## Included in this starter
- Responsive home screen
- Hindi / English language toggle
- Service tiles for Recharge, DTH, Shopping, Finance, Retailer and Support
- Demo product cards and cart-add interaction
- Demo mobile login (OTP is `123456`; no SMS is sent)
- PWA manifest and service worker

## Important limitations
This is a front-end starter/demo, not a production financial or recharge app. It does **not** process real recharges, payments, loans, money transfers, orders, or real OTP messages. Never collect real customer OTPs or financial credentials in this demo. Before launch, add a secure backend, database, authentication, privacy policy, and authorized API/partner integrations. Never put secret API keys in browser JavaScript or a public GitHub repository.

## Run on your laptop
1. Install a code editor such as Visual Studio Code: https://code.visualstudio.com/
2. Download and install Git: https://git-scm.com/downloads
3. Extract this ZIP file.
4. Open the extracted `my-world-starter` folder in VS Code.
5. Install the VS Code extension **Live Server**.
6. Right-click `index.html` and choose **Open with Live Server**.

## Publish free with GitHub Pages
1. Sign in at https://github.com/ and create a new **Public** repository named `my-world`.
2. In the repository choose **Add file → Upload files**.
3. Upload the contents of this folder (not the outer ZIP).
4. Commit the files to the `main` branch.
5. Open **Settings → Pages**.
6. Under Build and deployment choose **Deploy from a branch**.
7. Select branch `main` and folder `/ (root)`, then Save.
8. Wait for the Pages deployment. GitHub will show your website URL in Settings → Pages.

## Install on Android
1. Open the published HTTPS GitHub Pages URL in Chrome.
2. Open Chrome menu (⋮).
3. Choose **Install app** or **Add to Home screen**.

## Next development stages
1. Connect Firebase Authentication for real phone OTP (requires Firebase setup and may have quotas/billing requirements).
2. Add Firestore or another database with security rules.
3. Build a secure backend for products, orders and retailer accounts.
4. Integrate authorized recharge / bill-payment provider APIs.
5. Integrate a compliant payment gateway and financial partners.
6. Add admin dashboard, audit logs, privacy policy and terms.
