const products = [
  {id:1,nameHi:"वायरलेस ईयरबड्स",nameEn:"Wireless Earbuds",price:799,emoji:"🎧",kind:"Demo product"},
  {id:2,nameHi:"फास्ट चार्जर",nameEn:"Fast Charger",price:499,emoji:"🔌",kind:"Demo product"},
  {id:3,nameHi:"ब्लूटूथ स्पीकर",nameEn:"Bluetooth Speaker",price:1199,emoji:"🔊",kind:"Demo product"},
  {id:4,nameHi:"पावर बैंक",nameEn:"Power Bank",price:999,emoji:"🔋",kind:"Demo product"}
];
let language = "hi";
let cart = [];
let loggedIn = false;
const $ = (id) => document.getElementById(id);
function showToast(message){const t=$("toast");t.textContent=message;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),2400)}
function renderProducts(){
  $("productGrid").innerHTML=products.map(p=>`<article class="product-card"><div class="product-art" aria-hidden="true">${p.emoji}</div><div class="product-info"><b>${language==="hi"?p.nameHi:p.nameEn}</b><small>${p.kind}</small><div class="price-row"><span class="price">₹${p.price.toLocaleString("en-IN")}</span><button class="add-btn" data-add="${p.id}">${language==="hi"?"जोड़ें":"Add"}</button></div></div></article>`).join("");
}
function setLanguage(){
  document.documentElement.lang=language;
  document.querySelectorAll("[data-hi]").forEach(el=>{el.textContent=el.dataset[language]});
  $("langBtn").textContent=language==="hi"?"English":"हिंदी";
  renderProducts();
}
$("langBtn").addEventListener("click",()=>{language=language==="hi"?"en":"hi";setLanguage()});
$("loginOpen").addEventListener("click",()=>{$("loginDialog").showModal();$("loginMessage").textContent="";$("otpArea").hidden=true});
$("sendOtp").addEventListener("click",()=>{
  const mobile=$("mobile").value.trim();
  if(!/^[6-9]\d{9}$/.test(mobile)){showToast(language==="hi"?"कृपया सही 10 अंकों का मोबाइल नंबर डालें":"Enter a valid 10-digit Indian mobile number");return}
  $("otpArea").hidden=false;
  $("loginMessage").textContent=language==="hi"?"डेमो OTP: 123456 (कोई SMS नहीं भेजा गया)":"Demo OTP: 123456 (No SMS was sent)";
});
$("verifyOtp").addEventListener("click",()=>{
  if($("otp").value.trim()!=="123456"){showToast(language==="hi"?"गलत OTP":"Incorrect OTP");return}
  loggedIn=true;$("loginDialog").close();$("loginOpen").textContent=language==="hi"?"मेरा अकाउंट":"My account";showToast(language==="hi"?"डेमो लॉगिन सफल":"Demo login successful");
});
const serviceInfo={
 recharge:["मोबाइल रिचार्ज","यह डेमो स्क्रीन है। असली रिचार्ज के लिए अधिकृत Recharge API और सर्वर इंटीग्रेशन जोड़ना होगा।"],
 dth:["DTH रिचार्ज","असली DTH भुगतान अभी सक्रिय नहीं है। अधिकृत बिल-पेमेंट पार्टनर की जरूरत होगी।"],
 finance:["फाइनेंस","यहाँ बाद में अधिकृत वित्तीय पार्टनर की सेवाएँ जोड़ी जा सकती हैं। अभी कोई लोन या भुगतान उपलब्ध नहीं है।"],
 retailer:["रिटेलर बनें","रिटेलर रजिस्ट्रेशन, KYC और कमीशन सिस्टम अगले चरण में बनाया जाएगा।"],
 support:["Help & Support","अपना सपोर्ट ईमेल और WhatsApp नंबर जोड़ने के बाद ग्राहक यहाँ संपर्क कर सकेंगे।"],
 orders:["मेरे ऑर्डर","आपके डेमो कार्ट में "+cart.length+" प्रोडक्ट हैं। वास्तविक ऑर्डर के लिए backend और payment integration चाहिए।"],
 account:["मेरा अकाउंट",loggedIn?"आप डेमो अकाउंट में लॉगिन हैं।":"कृपया पहले मोबाइल नंबर से डेमो लॉगिन करें।"]
};
function openInfo(key){
 if(key==="shopping"){ $("shopSection").scrollIntoView({behavior:"smooth"});return; }
 const info=serviceInfo[key]||["MY WORLD","यह सुविधा अगले चरण में जोड़ी जाएगी।"];
 $("infoTitle").textContent=info[0];$("infoText").textContent=info[1];$("infoDialog").showModal();
}
$("serviceGrid").addEventListener("click",e=>{const b=e.target.closest("[data-service]");if(b)openInfo(b.dataset.service)});
$("productGrid").addEventListener("click",e=>{const b=e.target.closest("[data-add]");if(!b)return;const p=products.find(x=>x.id===Number(b.dataset.add));cart.push(p);showToast(language==="hi"?p.nameHi+" कार्ट में जोड़ा गया":"Added "+p.nameEn+" to cart")});
$("viewAll").addEventListener("click",()=>showToast(language==="hi"?"अभी डेमो प्रोडक्ट दिखाए जा रहे हैं":"Showing demo products"));
$("infoClose").addEventListener("click",()=>$("infoDialog").close());
$("infoOk").addEventListener("click",()=>$("infoDialog").close());
document.querySelector(".bottom-nav").addEventListener("click",e=>{const b=e.target.closest("[data-nav]");if(!b)return;document.querySelectorAll(".bottom-nav button").forEach(x=>x.classList.remove("active"));b.classList.add("active");if(b.dataset.nav==="home")window.scrollTo({top:0,behavior:"smooth"});else openInfo(b.dataset.nav)});
renderProducts();
if("serviceWorker" in navigator && location.protocol.startsWith("http")){window.addEventListener("load",()=>navigator.serviceWorker.register("./sw.js").catch(err=>console.log("Service worker registration failed",err)))}
